import cv2
import numpy as np
import torch
import csv
import time
import threading
import logging
from datetime import datetime
from ultralytics import YOLO
from tkinter import Tk, Button, Label, filedialog
from PIL import Image, ImageTk
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import os

# ---------- CONFIGURATION ----------
model_path = 'best74.pt'
csv_file = '/home/user/Desktop/Data/resultats.csv'
logo_path = 'logo.png'  # Facultatif
window_title = "Détection de Défauts - Eleonetech"
class_names = ["corps jaune", "court circuit", "gravure", "resistance", "vernis"]
# -----------------------------------

# Chargement du modèle
model = YOLO(model_path)

# Initialisation webcam
cap = cv2.VideoCapture(0)

# Logging
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(message)s')
logging.info("Application démarrée")

# Initialisation CSV
if not os.path.exists(csv_file):
    with open(csv_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Horodatage", "Statut", "Défauts détectés"])
        logging.info("Fichier CSV initialisé")

# Variables globales
capture_running = False

def analyser_et_sauvegarder(image):
    results = model.predict(source=image, verbose=False)
    result_image = results[0].plot()

    detected_classes = set()
    for result in results:
        for detection in result.boxes.data.tolist():
            class_id = int(detection[5])
            detected_classes.add(class_id)

    defects = []
    if 0 in detected_classes:
        defects.append("Présence de corps jaune")
    if 1 in detected_classes:
        defects.append("Court-circuit détecté")
    if 2 not in detected_classes:
        defects.append("Gravure manquante")
    if 3 not in detected_classes:
        defects.append("Résistance manquante")
    if 4 in detected_classes:
        defects.append("Vernis présent")

    status = "✅ Conforme" if not defects else "❌ Non conforme"
    horodatage = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Sauvegarde CSV
    with open(csv_file, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([horodatage, status, "; ".join(defects) if defects else "Aucun"])

    logging.info(f"Analyse: {status} | Défauts: {defects if defects else 'Aucun'}")

    # Affichage image dans l'app
    image_rgb = cv2.cvtColor(result_image, cv2.COLOR_BGR2RGB)
    image_pil = Image.fromarray(image_rgb)
    image_tk = ImageTk.PhotoImage(image_pil)
    label_img.config(image=image_tk)
    label_img.image = image_tk

    # Affichage du statut
    label_statut.config(text=status, fg="green" if status == "✅ Conforme" else "red")

    # Affichage des défauts
    texte_defauts = "\n".join(defects) if defects else "Aucun défaut détecté"
    label_defauts.config(text=texte_defauts)

def capture_loop():
    while capture_running:
        ret, frame = cap.read()
        if ret:
            analyser_et_sauvegarder(frame)
        time.sleep(5)

def start_capture():
    global capture_running
    capture_running = True
    threading.Thread(target=capture_loop, daemon=True).start()
    logging.info("Capture démarrée")

def stop_capture():
    global capture_running
    capture_running = False
    logging.info("Capture arrêtée")

def exporter_pdf():
    try:
        pdf_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("Fichiers PDF", "*.pdf")])
        if not pdf_path:
            return

        c = canvas.Canvas(pdf_path, pagesize=A4)
        width, height = A4
        c.setFont("Helvetica", 12)

        if os.path.exists(logo_path):
            c.drawImage(logo_path, 40, height - 80, width=100, preserveAspectRatio=True, mask='auto')

        c.drawString(150, height - 50, "Rapport de détection - Eleonetech")
        y = height - 100

        with open(csv_file, 'r') as f:
            for line in f:
                if y < 40:
                    c.showPage()
                    y = height - 40
                c.drawString(40, y, line.strip())
                y -= 20

        c.save()
        logging.info(f"Rapport exporté en PDF : {pdf_path}")
    except Exception as e:
        logging.error(f"Erreur lors de l'export PDF : {e}")

def uploader_image():
    file_path = filedialog.askopenfilename(
        title="Choisir une image",
        filetypes=[("Fichiers image", "*.jpg *.png *.jpeg")]
    )
    if file_path:
        image = cv2.imread(file_path)
        if image is not None:
            analyser_et_sauvegarder(image)
            logging.info(f"Image chargée depuis le disque : {file_path}")
        else:
            logging.error("Erreur lors du chargement de l'image.")

# Interface graphique
root = Tk()
root.title(window_title)
root.geometry("1000x800")  # 👈 Agrandissement de la fenêtre

# Logo
try:
    if os.path.exists(logo_path):
        img = Image.open(logo_path).resize((120, 60))
        logo = ImageTk.PhotoImage(img)
        Label(root, image=logo).pack(pady=5)
except:
    pass

# Boutons
Button(root, text="Démarrer la capture", command=start_capture, bg="green", fg="white", width=25).pack(pady=5)
Button(root, text="Arrêter la capture", command=stop_capture, bg="red", fg="white", width=25).pack(pady=5)
Button(root, text="Uploader une image", command=uploader_image, bg="#FFA500", fg="white", width=25).pack(pady=5)
Button(root, text="Exporter le rapport PDF", command=exporter_pdf, bg="blue", fg="white", width=25).pack(pady=5)

# Affichage des résultats
label_statut = Label(root, text="En attente...", font=("Helvetica", 14))
label_statut.pack(pady=5)

label_defauts = Label(root, text="", font=("Helvetica", 12), wraplength=900, justify="left")
label_defauts.pack(pady=5)

label_img = Label(root)
label_img.pack()

def on_close():
    stop_capture()
    cap.release()
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()
